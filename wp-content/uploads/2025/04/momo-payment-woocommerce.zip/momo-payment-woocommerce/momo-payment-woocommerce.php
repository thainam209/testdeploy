<?php
/**
 * Plugin Name: MoMo Payment Gateway for WooCommerce
 * Plugin URI: https://momo.vn
 * Description: Thanh toán qua MoMo QR/ATM cho WooCommerce.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL2
 */

if (!defined('ABSPATH')) exit;

add_action('plugins_loaded', 'momo_init_gateway_class');

function momo_init_gateway_class() {
    if (!class_exists('WC_Payment_Gateway')) return;

    include_once dirname(_FILE_) . '/includes/class-momo-gateway.php';

    add_filter('woocommerce_payment_gateways', function ($methods) {
        $methods[] = 'WC_Momo_Gateway';
        return $methods;
    });
}

