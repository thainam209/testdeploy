<?php

class WC_Momo_Gateway extends WC_Payment_Gateway {
    public function __construct() {
        $this->id = 'momo';
        $this->method_title = 'MoMo';
        $this->method_description = 'Thanh toán bằng ví điện tử MoMo.';
        $this->has_fields = false;

        $this->init_form_fields();
        $this->init_settings();

        $this->title = $this->get_option('title');
        $this->partner_code = $this->get_option('partner_code');
        $this->access_key = $this->get_option('access_key');
        $this->secret_key = $this->get_option('secret_key');
        $this->sandbox = $this->get_option('sandbox');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title' => 'Bật/Tắt',
                'label' => 'Bật MoMo',
                'type' => 'checkbox',
                'default' => 'yes'
            ],
            'title' => [
                'title' => 'Tiêu đề',
                'type' => 'text',
                'default' => 'Thanh toán qua MoMo'
            ],
            'partner_code' => [
                'title' => 'Partner Code',
                'type' => 'text'
            ],
            'access_key' => [
                'title' => 'Access Key',
                'type' => 'text'
            ],
            'secret_key' => [
                'title' => 'Secret Key',
                'type' => 'text'
            ],
            'sandbox' => [
                'title' => 'Chế độ test (Sandbox)',
                'type' => 'checkbox',
                'default' => 'yes'
            ]
        ];
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);

        $endpoint = $this->sandbox == 'yes' ? 
            'https://test-payment.momo.vn/v2/gateway/api/create' : 
            'https://payment.momo.vn/v2/gateway/api/create';

        $requestId = time() . "";
        $orderId = $order->get_id();
        $amount = (int)$order->get_total();
        $redirectUrl = $order->get_checkout_order_received_url();
        $ipnUrl = home_url('/');

        $rawHash = "accessKey={$this->access_key}&amount=$amount&extraData=&ipnUrl=$ipnUrl&orderId=$orderId&orderInfo=Thanh+toan+don+hang&partnerCode={$this->partner_code}&redirectUrl=$redirectUrl&requestId=$requestId&requestType=captureWallet";
        $signature = hash_hmac("sha256", $rawHash, $this->secret_key);

        $data = [
            'partnerCode' => $this->partner_code,
            'accessKey' => $this->access_key,
            'requestId' => $requestId,
            'amount' => "$amount",
            'orderId' => "$orderId",
            'orderInfo' => 'Thanh toán đơn hàng',
            'redirectUrl' => $redirectUrl,
            'ipnUrl' => $ipnUrl,
            'extraData' => '',
            'requestType' => 'captureWallet',
            'signature' => $signature,
            'lang' => 'vi'
        ];

        $result = wp_remote_post($endpoint, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => json_encode($data),
            'timeout' => 45,
        ]);

        if (!is_wp_error($result)) {
            $body = json_decode($result['body'], true);
            if (isset($body['payUrl'])) {
                return [
                    'result' => 'success',
                    'redirect' => $body['payUrl']
                ];
            }
        }

        wc_add_notice('Có lỗi khi kết nối MoMo.', 'error');
        return;
    }
}